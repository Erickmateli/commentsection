<?php 
date_default_timezone_set('Africa/Nairobi');
include 'conn.php';
include 'commentfunctions.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>edit</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php 
error_reporting(0);

	$cid = $_POST['cid'];

	$uid = $_POST['uid'];

	$date = $_POST['date'];

	$message = $_POST['message'];

 	echo"<form class='comment' method='POST' action='".editComment($conn)."'>
	 <h1> edit comments here</h1>
	 <input type='hidden' name='cid' value='".$cid."'>
	<input type='hidden' name='uid' value='".$uid."'>
	<input type='hidden' name='date' value='".$date."'>
	<textarea type='text' name='message' >".$message."</textarea><br>
	<button type='submit' name='editSubmit'>edit</button>
	</form>";
	?>
</body>
</html>