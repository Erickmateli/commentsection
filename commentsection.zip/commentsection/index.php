<?php 
date_default_timezone_set('Africa/Nairobi');
include 'conn.php';
include 'commentfunctions.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>comments</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<img src="images/php.png">
	<?php 
	 echo"<form class='comment' method='POST' action='".setComment($conn)."'>
	 <h1>comments here</h1>
	<input type='hidden' name='uid' value='anonymous'>
	<input type='hidden' name='date' value='".date('Y-m-d H:i:s')."'>
	<textarea type='text' name='message'></textarea><br>
	<button type='submit' name='commentSubmit'>comment</button>
	</form>";
	getComment($conn)
	?>
</body>
</html>